import pygame, pgeng, time
import os
from pygame.locals import *

#region basic info
pygame.init()
pgeng.tile_size = 20


width,height = 500, 300
screen = pgeng.Screen((width, height))

display = screen.get_display()
clock = pygame.time.Clock()

score = 0
font = pygame.font.SysFont(None, 30)

playing = 2
level = 0
gravity = 0.1
mobs = []
#endregion

#region sprites

sprite_game_over = pygame.image.load('game_over.png').convert_alpha()
sprite_game_won = pygame.image.load('game_won.png').convert_alpha()
sprite_coin = pygame.image.load('coin.png').convert_alpha()
sprite_flag = pygame.image.load('flag.png').convert_alpha()

sprite_hero_current = pygame.image.load('hero.png').convert_alpha()
sprite_hero_idle = pygame.image.load('hero.png').convert_alpha()
sprite_hero_shoot = pygame.image.load('hero_shoot.png').convert_alpha()
sprite_hero_bullet = pygame.image.load('hero_bullet.png').convert_alpha()
sprite_heart = pygame.image.load('hero_health.png').convert_alpha()
sprite_hero_lives = pygame.image.load('hero_lives.png').convert_alpha()


sprite_human1 = pygame.image.load('human1.png').convert_alpha()
sprite_human1_bullet = pygame.image.load('human1_bullet.png').convert_alpha()

sprite_human2 = pygame.image.load('human2.png').convert_alpha()

sprite_boss = pygame.image.load('boss.png').convert_alpha()
#endregion

class player:
    max_health = 3
    health = max_health
    lives = 2
    def hit(self, damage):
        self.health -= damage
        
    width = 28
    height = 30
    
    spawn = pygame.Vector2(50, 270)
    entity = pgeng.Entity(spawn, (width, height))
        
    shoot = True
    bulletattackspeed = 0.5
    bulletlastfired = 0
    bulletsize = 6
    bulletspeed = 1
    bulletcolor = '#ff8383'
    bullets = []
    bulletmax = 10
    
    x, y = 0, 0
    truex, truey = 0,0
    
    sprite_can_change = True

    
    falling = False
    y_momentum = 0
    air_timer = 0
    jump_power = -3
    jumping = False
    
    look_right = True
    
class coin:
    def __init__(self,x,y,state,sprite):
        self.spawn = pygame.Vector2(x-14, y-20)
        self.box = pgeng.Entity(self.spawn, (20, 20))
        self.sprite = sprite
        self.state = state
        
    def update(self):
        display.blit(self.sprite, (self.box.rect.topleft[0] - scroll.x, self.box.rect.topleft[1] - scroll.y))
        if self.box.rect.colliderect(player.entity):
            self.touch()
                
    def touch(self):
        global score
        global level
        global tile_map
        global mobs
        global coins
        global levelcoins
        global playing
        
        if self.state == 1:
            score += 100
            coins.remove(self)
        
        elif self.state == 2:
            try:
                player.entity.location = player.spawn
                level += 1
                tile_map = TileMap(tile_map_data[level], tile_images)
                mobs = levelmobs[level]
                coins = levelcoins[level]
            except:
                playing = 4
        

class entity_mob:
    def __init__(self, health, width, height, sprite, side, spawnx, spawny, bulletspeed, attackspeed, bulletsprite, score):
        self.health = health
        self.width = width
        self.height = height
        
        self.sprite = sprite
        self.facing = side
        self.x = spawnx
        self.y = spawny
        self.spawn = pygame.Vector2(self.x -14, self.y)
        self.box = pgeng.Entity(self.spawn, (self.width, self.height))
        self.score = score

        self.bullets = []
        self.bullet_speed = bulletspeed
        self.bullet_attackspeed = attackspeed
        self.bulletsize = 5
        self.bulletspeed = 3
        self.bulletcolor = "000"
        self.bulletdir = 1
            
        if self.facing == False:
            self.sprite = pygame.transform.flip(self.sprite, True, False)

        
        
        self.bullet_sprite = bulletsprite
        self.shoot = False
        self.wait = time.time()
        
        self.y_momentum = 0
        self.air_timer = 0
        self.falling = False
        self.jumping = False

        self.font = pygame.font.Font(None, 24)

    def hit(self, damage):
        self.health -= damage
        
        if self.health <= 0:
            self.die()
        
    def check_bullet_collision(self, player_bullets):
            for bullet in player_bullets:
                bullet_rect = pygame.Rect(bullet.x, bullet.y, bullet.radius * 2, bullet.radius * 2)
                if self.box.rect.colliderect(bullet_rect):
                    self.hit(1)
                    player_bullets.remove(bullet)
                
    def die(self):
        mobs.remove(self)
        global score
        score += self.score
                
    def entity_gravity(self, dt, tile_map):
        self.y_momentum += gravity * dt
        collision_tiles = tile_map.get_collision_tiles()

        collisions = self.box.movement(pygame.Vector2(0, self.y_momentum * dt), collision_tiles)
            

        if collisions['bottom']:
            self.y_momentum = 0
            self.air_timer = 0
            self.falling = False
            self.jumping = False
        else:
            self.air_timer += dt
            self.falling = True

        if collisions['top']:
            self.y_momentum = 0
            
    def shoot_bullet(self):
        if time.time() >= self.wait:
            
            self.truex = round(self.box.rect.centerx)
            self.truey = round(self.box.rect.centery)

            self.bullets.append(Projectile(self.truex, self.truey - 7, self.bulletsize, self.bulletcolor, self.bulletdir, self.bullet_speed, self.bullet_sprite, self.facing))
            self.wait = time.time() + self.bullet_attackspeed
        
            
    def bullet_update(self):

        try:
            for bullet in self.bullets:
                
                
                
                if self.facing == True:
                    bullet.x += bullet.vel
                else:
                    bullet.x -= bullet.vel
                    
                bullet.draw(display, scroll)

                
                if bullet.check_tile_collision(tile_map):
                    self.bullets.remove(bullet)
                    continue
                
                if bullet.check_player_collision():
                    self.bullets.remove(bullet)
                    player.health -= 1
                    continue
                
                
        except:
            "dw"
            
    def render(self, display, scroll):
        
        display.blit(self.sprite, (self.box.rect.topleft[0] - scroll.x, self.box.rect.topleft[1] - scroll.y))
        
        health_text = self.font.render(f"{self.health}", True, (255, 0, 0))
        health_text_pos = (self.box.rect.centerx - health_text.get_width() // 2 - scroll.x,self.box.rect.top - 20 - scroll.y) 
        
        display.blit(health_text, health_text_pos)
        
    def talkshit(self):
        
        display.blit(self.sprite, (self.box.rect.topleft[0] - scroll.x, self.box.rect.topleft[1] - scroll.y))
        
        boss_text = self.font.render("I HATE KISSES!", True, (255, 0, 0))
        boss_text_pos = (self.box.rect.centerx - boss_text.get_width() // 2 - scroll.x,self.box.rect.top - 40 - scroll.y) 
        
        display.blit(boss_text, boss_text_pos)

    def update(self, dt, tile_map, display, scroll):
        self.entity_gravity(dt, tile_map)
        self.render(display, scroll)
        self.check_bullet_collision(player.bullets)
        self.shoot_bullet()
        self.bullet_update()
        
        if self.health > 10:
            self.talkshit()





    
class Projectile:
    def __init__(self, x, y, radius, color, facing, speed, image, lookright):
        self.x = x
        self.y = y
        self.radius = radius
        self.color = color
        self.facing = facing
        self.vel = speed * facing
        
        if lookright:
            self.image = image
        else:
            self.image =  pygame.transform.flip(image, True, False)

    def draw(self, win, scroll):
        win.blit(self.image, (self.x - scroll.x - self.radius - 10, self.y - scroll.y - self.radius - 10))

    def check_tile_collision(self, tile_map):
            bullet_rect = pygame.Rect(self.x, self.y, self.radius * 2, self.radius * 2)
            for tile in tile_map.get_collision_tiles():
                if bullet_rect.colliderect(tile.rect):
                    return True
            return False
        
    def check_player_collision(self):
            bullet_rect = pygame.Rect(self.x, self.y, self.radius * 2, self.radius * 2)
            if bullet_rect.colliderect(player.entity):
                return True
            return False
        
    #bullet_rect = pygame.Rect(self.x - scroll.x - self.radius, self.y - scroll.y - self.radius, self.radius * 2, self.radius * 2)
    #pygame.draw.rect(win, (255, 0, 0), bullet_rect, 2)  # Red color hitbox with 2-pixel width

#region tilemaps/level design



#camera scroll
scroll_change = [(screen.size[i] + player.entity.rect.size[i]) * 0.5 for i in range(2)] 
scroll = player.entity.center - scroll_change


class Tile:
    def __init__(self, x, y, image, ramp=False):
        self.image = image
        self.rect = pygame.Rect(x, y, pgeng.tile_size, pgeng.tile_size)
        self.ramp = ramp 


class Tile:
    def __init__(self, x, y, image, ramp=False):
        self.image = image
        self.rect = pygame.Rect(x, y, image.get_width(), image.get_height())
        self.ramp = ramp 


class TileMap:
    def __init__(self, tile_map, tile_images):
        self.tile_map = tile_map
        self.tile_images = tile_images
        self.tiles = []


        for row_index, row in enumerate(tile_map):
            for col_index, tile_type in enumerate(row):
                if tile_type in self.tile_images:

                    x = col_index * self.tile_images[tile_type].get_width()
                    y = row_index * self.tile_images[tile_type].get_height()
                    self.tiles.append(Tile(x, y, self.tile_images[tile_type]))

    def render(self, display, scroll):
        for tile in self.tiles:
            display.blit(tile.image, (tile.rect.x - scroll.x, tile.rect.y - scroll.y))

    def get_collision_tiles(self):
        return self.tiles


tile_map_data = [
[#level 1
    [1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1],
    [1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1],
    [1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1],
    [1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1],
    [1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1],
    [1,0,0,0,0,0,3,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1],
    [1,0,0,0,0,0,0,0,3,0,0,0,0,2,0,0,0,0,0,0,0,0,0,0,0,0,0,1],
    [1,0,0,0,0,0,0,0,0,0,2,0,0,1,2,0,0,0,0,0,0,0,0,0,0,0,0,1],
    [1,0,0,0,2,2,0,0,0,0,0,0,2,1,1,2,0,0,0,0,0,0,0,0,2,2,2,1],
    [1,2,2,2,1,1,2,2,2,2,2,2,1,1,1,1,2,2,2,2,2,2,2,2,1,1,1,1],
    [1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1],
    [1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1],
    [1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1],
    [1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1],
    [1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1]
],
[#level 2
    [1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1],
    [1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1],
    [1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1],
    [1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1],
    [1,0,0,0,0,0,0,0,3,0,3,0,3,0,3,0,3,0,3,0,3,0,3,0,3,0,3,3,3,3,0,0,0,0,1],
    [1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,2,0,1],
    [1,0,0,0,2,2,2,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,2,0,0,0,1],
    [1,0,0,0,1,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,2,0,0,0,0,0,1],
    [1,0,0,0,0,0,0,0,0,0,2,0,0,0,2,0,0,2,0,0,2,0,0,0,0,0,2,0,0,0,0,0,0,0,1],
    [1,2,2,2,2,2,2,2,2,2,1,2,2,2,1,2,2,1,2,2,1,2,2,2,2,2,1,2,2,2,2,2,2,2,1],
    [1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1],
    [1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1],
    [1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1],
    [1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1],
    [1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1] 
],
[#level 3          
    [1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1],
    [1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1],
    [1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1],
    [1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1],
    [1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1],
    [1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1],
    [1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1],
    [1,0,0,0,0,2,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1],
    [1,0,0,0,2,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1],
    [1,2,2,2,1,1,2,0,2,0,2,0,2,0,2,0,2,2,2,2,2,1],
    [1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1],
    [1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1],
    [1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1],
    [1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1],
    [1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1] 
]      
]


#              health, width, height, sprite, side, spawnx, spawny, bulletspeed, attackspeed, bulletsprite, score
levelmobs = [
[#level 1
    entity_mob(2, 28, 30, sprite_human1, False, 366, 273, 2, 2, sprite_human1_bullet, 100),
    entity_mob(2, 28, 30, sprite_human1, False, 811, 241, 2, 2, sprite_human1_bullet, 100),
    entity_mob(2, 28, 30, sprite_human1, False, 721, 273, 2, 2, sprite_human1_bullet, 100)
],
[#level 2
    entity_mob(1, 28, 30, sprite_human2, False, 494, 273, 2, 2000, sprite_human1_bullet, 100),
    entity_mob(1, 28, 30, sprite_human2, False, 530, 273, 2, 2000, sprite_human1_bullet, 100),
    entity_mob(1, 28, 30, sprite_human2, False, 590, 273, 2, 2000, sprite_human1_bullet, 100),
    entity_mob(1, 28, 30, sprite_human2, False, 626, 273, 2, 2000, sprite_human1_bullet, 100),
    entity_mob(1, 28, 30, sprite_human2, False, 1038, 145, 2, 2000, sprite_human1_bullet, 100),
    entity_mob(1, 28, 30, sprite_human2, False, 206, 177, 2, 2000, sprite_human1_bullet, 100),
    entity_mob(1, 28, 30, sprite_human2, False, 143, 177, 2, 2000, sprite_human1_bullet, 100),
    
    entity_mob(2, 28, 30, sprite_human1, False, 463, 241, 2, 2, sprite_human1_bullet, 100),
    entity_mob(2, 28, 30, sprite_human1, False, 813, 273, 2, 2, sprite_human1_bullet, 100),
    entity_mob(2, 28, 30, sprite_human1, True, 848, 113, 2, 2, sprite_human1_bullet, 100)
],
[#level 3
    entity_mob(1, 28, 30, sprite_human2, False, 302, 305, 2, 2000, sprite_human1_bullet, 100),
    entity_mob(1, 28, 30, sprite_human2, False, 430, 305, 2, 2000, sprite_human1_bullet, 100),
    entity_mob(10000, 28, 30, sprite_boss, False, 564, 273, 2, 1, sprite_human1_bullet, 1000)
]
]

levelcoins = [
    #x, y, state, sprite
[#level 1
    #cheatflag
    #coin(112,273,2,sprite_flag),

    coin(271,177,1,sprite_coin),
    coin(208,145,1,sprite_coin),
    coin(830,241,2,sprite_flag)
],
[#level 2
     #cheatflag
    #coin(112,273,2,sprite_flag),
    
    coin(1079,273,1,sprite_coin),
    coin(331,241,1,sprite_coin),
    coin(175,177,2,sprite_flag) 
],
[#level 3
    coin(659,273,2,sprite_flag)

]
]









coins = levelcoins[level]
mobs = levelmobs[level]

tile_images = {
    1: pygame.image.load("tile_dirt.png").convert_alpha(),
    2: pygame.image.load("tile_grass.png").convert_alpha(),
    3: pygame.image.load("tile_sky.png").convert_alpha()
}

tile_map = TileMap(tile_map_data[level], tile_images)

def mob_ticks(dt, tile_map, display, scroll):
    for mob in mobs:
        mob.update(dt, tile_map, display, scroll)


def reset():
    if player.lives > 0:
        player.lives -= 1
        player.health = player.max_health
        player.entity.location = player.spawn
    else:
        global playing
        playing = 3



#endregion

while True:
    #========================================================================================================WHILE TRUE LOOP START==========================================================================================================================
#region constant tick updates
    print (f"X:{player.truex} \t Y:{player.truey} \t")

    #bg color
    display.fill((116, 215, 228))

    



    if playing == 3:

        center_x = (width - sprite_game_over.get_width()) // 2 
        center_y = (height - sprite_game_over.get_height()) // 2  

        display.blit(sprite_game_over, (center_x, center_y))
        
        
    if playing == 4:

        center_x = (width - sprite_game_won.get_width()) // 2 
        center_y = (height - sprite_game_won.get_height()) // 2  

        display.blit(sprite_game_won, (center_x, center_y))
        


    elif playing == 2:
        
        
        player.x = round(player.entity.rect.centerx - scroll.x)
        player.y = round(player.entity.rect.centery - scroll.y)
        player.truex = round(player.entity.rect.centerx)
        player.truey = round(player.entity.rect.centery)

        dt = pgeng.delta_time(clock, 144)

        scroll.x += (player.entity.center.x - scroll.x - scroll_change[0]) / 20 * dt
        scroll.y += (player.entity.center.y - scroll.y - scroll_change[1]) / 20 * dt
        
        
        
        #player sprite
        display.blit(sprite_hero_current, (player.entity.rect.topleft[0] - scroll.x, player.entity.rect.topleft[1] - scroll.y))
        #player hitbox
        #pygame.draw.rect(display, (255, 0, 0), (player.entity.rect.x - scroll.x, player.entity.rect.y - scroll.y, player.entity.rect.width, player.entity.rect.height), 2)

        for e in range(player.health):
            display.blit(sprite_heart,(14*e,10))

        for e in range(player.lives + 1):
            display.blit(sprite_hero_lives,(3+(14*e),20))
        
        
    #endregion
        mob_ticks(dt, tile_map, display, scroll)
        
        for e in coins:
            e.update()
        
        keys = pygame.key.get_pressed()
        x_momentum = 0
        if keys[K_d]:
            x_momentum += 1.0 * dt
            if not player.look_right:
                player.look_right = True


        if keys[K_a]:
            x_momentum -= 1.0 * dt
            if player.look_right:
                player.look_right = False
                
                
        if player.look_right:
            sprite_hero_current = sprite_hero_idle
            
        elif player.look_right is False:
            sprite_hero_current = pygame.transform.flip(sprite_hero_idle, True, False)

        tile_map.render(display, scroll)

        #Apply gravity and handle collisions
        player.y_momentum += gravity * dt
        if player.entity.center.y > 800:  #respawn upon entering void
            player.entity.location = player.spawn
            
        #player death
        if player.health <= 0:
            reset()

        collision_tiles = tile_map.get_collision_tiles()
        collisions = player.entity.movement(pygame.Vector2(x_momentum, player.y_momentum * dt), collision_tiles)

        #ground/ceiling collision
        if collisions['bottom']:
            player.y_momentum = 0
            player.air_timer = 0
            player.falling = False
            player.jumping = False

        else:
            player.air_timer += dt
            player.falling = True
        if collisions['top']:
            player.y_momentum = 0



    #region player shoot

        if keys[pygame.K_SPACE]:

            
            if player.look_right:
                facing = 1
                sprite_hero_current = sprite_hero_shoot
            else:
                facing = -1
                sprite_hero_current = pygame.transform.flip(sprite_hero_shoot, True, False)
            
            wait = time.time()
            
    
            if len(player.bullets) < player.bulletmax and player.shoot:
                
                if player.look_right:
                    bullet_x = player.truex + player.width/2
                    
                else:
                    bullet_x = player.truex - player.width/2
                        
                bullet_y = player.truey + 3
                player.bullets.append(Projectile(bullet_x, bullet_y, player.bulletsize, player.bulletcolor, facing, player.bulletspeed, sprite_hero_bullet, player.look_right))
                player.bulletlastfired = time.time()
                player.shoot = False
    
                
                
        
        if time.time() >= (player.bulletlastfired + player.bulletattackspeed):
            player.shoot = True

                

        for bullet in player.bullets:
            if bullet.x < player.truex - screen.size[0] or bullet.x > player.truex + screen.size[0] or bullet.y < player.truey - screen.size[1] or bullet.y > player.truey + screen.size[1]:
                player.bullets.pop(player.bullets.index(bullet))
            if bullet.check_tile_collision(tile_map):
                player.bullets.pop(player.bullets.index(bullet))
            else:
                bullet.x += bullet.vel
                bullet.draw(display, scroll)
                
                
        for mob in mobs:
            if player.entity.rect.colliderect(mob.box) and sprite_hero_current == sprite_hero_shoot and mob.health > 10:
                mobs.remove(mob)
                
            elif player.entity.rect.colliderect(mob.box):
                mob.die()
                

    #endregion

    score_text = font.render(f"Score: {score}", True, "#000000")
    score_rect = score_text.get_rect()
    score_rect.topright = (width - 10, 10)
    display.blit(score_text, score_rect)


        # Event handling
    for event in pygame.event.get():
        if event.type == QUIT:
            pygame.quit()
            exit()
        if event.type == KEYDOWN:
            if event.key == K_ESCAPE:
                pygame.quit()
                exit()
            if event.key == K_w and player.air_timer < 15 and not player.jumping:
                player.y_momentum = player.jump_power
                player.jumping = True

    pygame.display.update()
    clock.tick(144)
